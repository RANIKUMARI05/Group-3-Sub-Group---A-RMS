package com.innoverasolutions.resource_management.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EconomyController {

    // Simple navigation to the Economy page
    @GetMapping("/admin/economy")
    public String viewEconomyPage() {
        return "economy";  // Ensure this matches your HTML file name (economy.html)
    }

    // Navigation for Economy Report page
    @GetMapping("/economy/report")
    public String viewEconomyReportPage() {
        return "economy-report";  // Ensure this matches your HTML file name (economy-report.html)
    }

    // Another navigation method for other economy-related pages
    @GetMapping("/economy/overview")
    public String viewEconomyOverviewPage() {
        return "economy-overview";  // Ensure this matches your HTML file name (economy-overview.html)
    }

    // A navigation page for additional economy features
    @GetMapping("/economy/details")
    public String viewEconomyDetailsPage() {
        return "economy-details";  // Ensure this matches your HTML file name (economy-details.html)
    }
}
