package com.innoverasolutions.resource_management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.innoverasolutions.resource_management.repository.ResourceRepository;
import com.innoverasolutions.resource_management.model.Resource;

import java.util.List;

@Service
public class ReportService {

    @Autowired
    private ResourceRepository resourceRepository;

    public List<Resource> generateResourceReport() {
        return resourceRepository.findAll();
    }

    // Additional report methods can be added here.
}