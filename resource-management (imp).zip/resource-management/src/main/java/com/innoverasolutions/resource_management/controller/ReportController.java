package com.innoverasolutions.resource_management.controller;

import com.innoverasolutions.resource_management.service.ReportService;
import com.innoverasolutions.resource_management.model.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List; // Import the List class

@Controller
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/admin/report")
    public String viewReports(Model model) {
        List<Resource> resources = reportService.generateResourceReport(); // Now List is recognized
        model.addAttribute("resources", resources);
        return "report"; // Ensure this matches your HTML file name without the extension.
    }
}
